#!/bin/sh
# Copyright (C) 2016 evenS

URL="http://7xt1v0.com1.z0.glb.clouddn.com/"
APP_NAME="aria2c"
APP_TAR_FILE="$APP_NAME-gee.tar.gz"
APP_DIR="/var1/etc/$APP_NAME"

APP_PIDS=$(pgrep -f "APP_DIR/aria2c" | wc -l)

if [ "$APP_PIDS" = 0 ]; then 
    "$APP_DIR"/"$APP_NAME"ctrl.sh start 
fi


