#!/bin/sh /etc/rc.common
# Copyright (C) 2016 evenS

ARIA_FILE="aria-gee.tar.gz"
ARIA_DIR="/var1/etc/aria2c"

start()
{    
    $ARIA_DIR/aria2c --conf-path=$ARIA_DIR/aria2c.conf -D   
}

stop()
{
    ps | grep "$ADBYBY_DIR/aria2c" | grep -v 'grep' | grep -v 'aria2c.sh' | awk '{print $1}' |xargs kill -9
}